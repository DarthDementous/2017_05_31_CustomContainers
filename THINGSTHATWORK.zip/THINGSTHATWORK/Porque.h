#pragma once

class TestThing {
public:
	TestThing() {}
	~TestThing() {}

	void doThing() { int i = 0; }

private:

};